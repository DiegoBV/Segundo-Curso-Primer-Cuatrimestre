Diego Baratto Valdivia y Alejandro Mar�n P�rez
Hemos usado ttf y listas con iteradores